//Copyright 2024 sgeddis

#ifndef RECTANGLE_H
#define RECTANGLE_H

#include "PixelShape.h"

namespace CSCE240_Program6 {

class Rectangle : public PixelShape {
private:
    int length;
    int width;

public:
    Rectangle(int length = 2, int width = 1, char pixel = '*');
    virtual ~Rectangle();

    void SetLength(int length);
    void SetWidth(int width);

    int GetLength() const;
    int GetWidth() const;

    virtual Rectangle& operator*=(double scale) override;
    virtual void Print(bool fill = true) const override;
};

} // namespace CSCE240_Program6

#endif 