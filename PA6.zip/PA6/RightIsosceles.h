//Copyright 2024 sgeddis

#ifndef RIGHTISOSCELES_H
#define RIGHTISOSCELES_H

#include "PixelShape.h"

namespace CSCE240_Program6 {

class RightIsosceles : public PixelShape {
private:
    int leg;

public:
    RightIsosceles(int leg = 2, char pixel = '*');
    virtual ~RightIsosceles();

    void SetLeg(int leg);
    int GetLeg() const;

    virtual RightIsosceles& operator*=(double scale) override;
    virtual void Print(bool fill = true) const override;
};

} // namespace CSCE240_Program6

#endif // RIGHTISOSCELES_H