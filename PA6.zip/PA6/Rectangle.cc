//Copyright 2024 sgeddis

#include "Rectangle.h"
#include <iostream>

namespace CSCE240_Program6 {

Rectangle::Rectangle(int length, int width, char pixel) 
    : PixelShape("rectangle", pixel), length(length > 0 ? length : 2), width(width > 0 ? width : 1) {}

Rectangle::~Rectangle() {}

void Rectangle::SetLength(int new_length) {
    if (new_length > 0) {
        length = new_length;
    }
}

void Rectangle::SetWidth(int new_width) {
    if (new_width > 0) {
        width = new_width;
    }
}

int Rectangle::GetLength() const {
    return length;
}

int Rectangle::GetWidth() const {
    return width;
}

Rectangle& Rectangle::operator*=(double scale) {
    int new_length = static_cast<int>(length * scale);
    int new_width = static_cast<int>(width * scale);
    if (new_length >= 1 && new_width >= 1) {
        length = new_length;
        width = new_width;
    }
    return *this;
}

void Rectangle::Print(bool fill) const {
    std::cout << name << std::endl;
    for (int i = 0; i < length; ++i) {
        for (int j = 0; j < width; ++j) {
            if (fill || i == 0 || i == length - 1 || j == 0 || j == width - 1) {
                std::cout << pixel << " ";
            } else {
                std::cout << "  ";
            }
        }
        std::cout << std::endl;
    }
}

}