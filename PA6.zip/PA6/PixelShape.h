//Copyright 2024 sgeddis

#ifndef PIXELSHAPE_H
#define PIXELSHAPE_H

#include <string>

namespace CSCE240_Program6 {

class PixelShape {
protected:
    std::string name;
    char pixel;

public:
    PixelShape(const std::string& name = "?", char pixel = '*');
    virtual ~PixelShape();

    void SetName(const std::string& name);
    void SetPixel(char pixel);

    std::string GetName() const;
    char GetPixel() const;

    virtual void Print(bool fill = true) const = 0;
    virtual PixelShape& operator*=(double scale) = 0; // Pure virtual function
};

} // namespace CSCE240_Program6

#endif // PIXELSHAPE_H