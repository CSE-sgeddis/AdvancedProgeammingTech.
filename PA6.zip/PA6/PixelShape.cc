//Copyright 2024 sgeddis

#include "PixelShape.h"
#include <iostream>

namespace CSCE240_Program6 {

PixelShape::PixelShape(const std::string& name, char pixel) 
    : name(name.empty() ? "?" : name), pixel((pixel >= 33 && pixel <= 126) ? pixel : '*') {}

PixelShape::~PixelShape() {}

void PixelShape::SetName(const std::string& new_name) {
    if (!new_name.empty()) {
        name = new_name;
    }
}

void PixelShape::SetPixel(char new_pixel) {
    if (new_pixel >= 33 && new_pixel <= 126) {
        pixel = new_pixel;
    }
}

std::string PixelShape::GetName() const {
    return name;
}

char PixelShape::GetPixel() const {
    return pixel;
}

}