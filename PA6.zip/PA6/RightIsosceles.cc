//Copyright 2024 sgeddis

#include "RightIsosceles.h"
#include <iostream>

namespace CSCE240_Program6 {

RightIsosceles::RightIsosceles(int leg, char pixel) 
    : PixelShape("right isosceles triangle", pixel), leg(leg >= 2 ? leg : 2) {}

RightIsosceles::~RightIsosceles() {}

void RightIsosceles::SetLeg(int new_leg) {
    if (new_leg >= 2) {
        leg = new_leg;
    }
}

int RightIsosceles::GetLeg() const {
    return leg;
}

RightIsosceles& RightIsosceles::operator*=(double scale) {
    int new_leg = static_cast<int>(leg * scale);
    if (new_leg >= 2) {
        leg = new_leg;
    }
    return *this;
}

void RightIsosceles::Print(bool fill) const {
    std::cout << name << std::endl;
    for (int i = 1; i <= leg; ++i) {
        for (int j = 1; j <= i; ++j) {
            if (fill || j == 1 || j == i || i == leg) {
                std::cout << pixel << " ";
            } else {
                std::cout << "  ";
            }
        }
        std::cout << std::endl;
    }
}

}