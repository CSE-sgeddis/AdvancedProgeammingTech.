// Copyright Sgeddis 2024

#include "program2functions.h"

// Function 1: LeapYear
// Determines if a year is a leap year based on the rules provided
bool LeapYear(int year) {
	if (year % 400 == 0) return true;
	if (year % 100 == 0) return false;
	if (year % 4 == 0) return true;
	return false;
}


// Function 2: LastDayOfMonth
// Returns the number of days in a month, including February in leap years
int LastDayOfMonth(int month, int year) {
	if (month < 1 || month > 12) return 0;
	if (month == 2) {
		if (year <= 0) return 0;
		return LeapYear(year) ? 29 : 28;
	}
	int days_in_month[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	return days_in_month[month - 1];
}

// Function 3: ValidDate
// Checks if the date given is valid
bool ValidDate(int month, int day, int year) {
	if (year <= 0 || month < 1 || month > 12 || day < 1) return false;
	int last_day = LastDayOfMonth(month, year);
	return day <= last_day;
}

// Function 4: NextDate
// Updates to the next day
void NextDate(int &month, int &day, int &year) {
	if (!ValidDate(month, day, year)) return;
	day++;
	if (day > LastDayOfMonth(month, year)) {
		day = 1;
		month++;
		if (month > 12) {
			month = month + 1; 
			year++;
		}
	}
}

// Function 5: PreviousDate
// Updates to previous day
void PreviousDate(int &month, int &day, int &year) {
	if (!ValidDate(month, day, year)) return;
	day--;
	if (day < 1) {
		month--;
		if (month < 1) {
			month = 12;
			year--;
		}
		day = LastDayOfMonth(month, year);
	}
}
	