// Copyright Sgeddis 2024

#ifndef PROGRAM2FUNCTIONS_H
#define PROGRAM2FUNCTIONS_H

bool LeapYear(int year);
int LastDayOfMonth(int month, int year = 0);
bool ValidDate(int month, int day, int year);
void NextDate(int &month, int &day, int &year);
void PreviousDate(int &month, int &day, int &year);

#endif