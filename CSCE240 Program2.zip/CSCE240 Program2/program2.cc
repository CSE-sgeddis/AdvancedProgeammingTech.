// Copyright Sgeddis 2024

#include <iostream>
#include "program2functions.h"


// Will calculate the number of days between two dates running day-by-day until the two dates match
int DaysBetween(int m1, int d1, int y1, int m2, int d2, int y2) {
	int count = 0;
	while (m1 != m2 || d1 != d2 || y1 != y2) {
		if (y1 > y2 || (y1 == y2 && (m1 > m2 || (m1 == m2 && d1 > d2)))) {
			PreviousDate(m1, d1, y1);
			count--;
		} else {
			NextDate(m1, d1, y1);
			count++;
		}
	}
	return count;
}

// Reads two dates from the input, validate them, and print the number of days between them if valid.
int main() {
	int m1, d1, y1, m2, d2, y2;
	char slash;

	std::cin >> m1 >> slash >> d1 >> slash >> y1 >> m2 >> slash >> d2 >> slash >> y2;
	
	//Debugging output to make sure input is correctly recieved
	std::cout << "First date: " << m1 << "/" << d1 << "/" << y1 << std::endl;
    std::cout << "Second date: " << m2 << "/" << d2 << "/" << y2 << std::endl;

    if (!ValidDate(m1, d1, y1)) {
	
	if (!ValidDate(m1, d1, y1)) {
		std::cout << m1 << "/" << d1 << "/" << y1 << " is not a valid date" << std:: endl;
		return 0;
	}
	if (!ValidDate(m2, d2, y2)) {
		std::cout << m2 << "/" << d2 << "/" << y2 << " is not a valid date" << std::endl;
		return 0;
	}
	
	int diff = DaysBetween(m1, d1, y1, m2, d2, y2);
	if (diff == 0) {
		std::cout << m1 << "/" << d1 << "/" << y1 << " is 0 days before " << m2 << "/" << d2 << "/" << y2 << std::endl;
	} else if (diff > 0) {
		std::cout << m1 << "/" << d1 << "/" << y1 << " is " << diff << " days before " << m2 << "/" << d2 << "/" << y2 << std::endl;
	} else {
		std::cout << m1 << "/" << d1 << "/" << y1 << " is " << -diff << " days after " << m2 << "/" << d2 << "/" << y2 << std::endl;
	}
	
	return 0;
} 