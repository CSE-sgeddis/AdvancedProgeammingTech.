// Copyright 2024 sgeddis

#include"height.h"

#include<cmath>
#include<string>
using std::string;
#include<iostream>
using std::ostream;


Height::Height(double v, string u) : value_(v), unit_(u) {
  if (v < 0) value_ = 0;
  if (u != "inches" && u != "feet" && u != "centimeters" && u != "meters") {
    unit_ = "feet";
  }
}

void Height::SetValue(double v) {
  if (v >= 0) value_ = v;
}

void Height::SetUnits(const string& u) {
  if (u == "inches" || u == "feet" || u == "centimeters" || u == "meters") {
    unit_ = u;
  }
}

double Height::GetValue() const { return value_;}
string Height::GetUnits() const { return unit_;}

void Height::ConvertUnits(const string& newUnit) {
  if (unit_ == newUnit) return;
  
  const double feet_to_inches = 12.0;
  const double feet_to_centimeters = 30.48;
  const double feet_to_meters = 0.3048;
  const double inches_to_centimeters = 2.54;
  const double centimeters_to_meters = 0.01;
  const double meters_to_inches = 39.3701;  
  const double meters_to_feet = 3.28084;

    if (unit_ == "feet") {
        if (newUnit == "inches") value_ *= feet_to_inches;
        else if (newUnit == "centimeters") value_ *= feet_to_centimeters;
        else if (newUnit == "meters") value_ *= feet_to_meters;
    } else if (unit_ == "inches") {
        if (newUnit == "feet") value_ /= feet_to_inches;
        else if (newUnit == "centimeters") value_ *= inches_to_centimeters;
        else if (newUnit == "meters") value_ /= meters_to_inches;
    } else if (unit_ == "centimeters") {
        if (newUnit == "feet") value_ /= feet_to_centimeters;
        else if (newUnit == "inches") value_ /= inches_to_centimeters;
        else if (newUnit == "meters") value_ *= centimeters_to_meters;
    } else if (unit_ == "meters") {
        if (newUnit == "feet") value_ *= meters_to_feet;
        else if (newUnit == "inches") value_ *= meters_to_inches;
        else if (newUnit == "centimeters") value_ *= 100;
    } 
	
	unit_ = newUnit;
	value_ = std::round(value_ * 100000) / 100000;
}

ostream& operator<<(ostream& os, const Height& h) {
  os << h.value_ << " " << h.unit_;
  return os;
}