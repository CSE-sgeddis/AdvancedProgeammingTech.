// Copyright 2024 sgeddis

#ifndef HEIGHTRANGE_H_
#define HEIGHTRANGE_H_

#include "height.h"

class HeightRange {
 public:
  HeightRange();  // Default constructor
  HeightRange(const Height& h1, const Height& h2);  // Constructor with two heights
  
  void SetShortest(const Height& h);  // Set shortest height
  void SetTallest(const Height& h);  // Set tallest height
  Height GetShortest() const;  // Accessor for shortest height
  Height GetTallest() const;  // Accessor for tallest height
  
  bool InRange(const Height& h, bool includeEndpoints = true) const;  // Check if height is in range
  Height Width() const;  // Get the width of the height range

 private:
  Height shortestHeight_;
  Height tallestHeight_;
};

#endif