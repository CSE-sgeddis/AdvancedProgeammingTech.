// Copyright 2024 sgeddis
#ifndef HEIGHT_H_
#define HEIGHT_H_

#include<string>
using std::string;
#include<iostream>
using std::ostream;

class Height {
	friend ostream& operator << (ostream&, const Height&);

  public:
	Height(double v = 0.0, string u = "feet");
	void SetValue(double v);
	void SetUnits(const string& u);
	double GetValue() const;
	string GetUnits() const;
	void ConvertUnits(const string& newUnit);
	
	
  private:
	double value_; //Height value
	string unit_;
};

#endif
  