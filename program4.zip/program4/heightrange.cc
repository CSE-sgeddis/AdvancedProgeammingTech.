// Copyright 2024 sgeddis

#include "heightrange.h"

HeightRange::HeightRange() : shortestHeight_(0, "feet"), tallestHeight_(0, "feet") {}

HeightRange::HeightRange(const Height& h1, const Height& h2) {
  if (h1.GetValue() < h2.GetValue()) {
    shortestHeight_ = h1;
    tallestHeight_ = h2;
  } else {
    shortestHeight_ = h2;
    tallestHeight_ = h1;
  }
}

void HeightRange::SetShortest(const Height& h) {
  if (h.GetValue() <= tallestHeight_.GetValue()) {
    shortestHeight_ = h;
  }
}

void HeightRange::SetTallest(const Height& h) {
  if (h.GetValue() >= shortestHeight_.GetValue()) {
    tallestHeight_ = h;
  }
}

Height HeightRange::GetShortest() const {
  return shortestHeight_;
}

Height HeightRange::GetTallest() const {
  return tallestHeight_;
}

bool HeightRange::InRange(const Height& h, bool includeEndpoints) const {
  if (includeEndpoints) {
    return h.GetValue() >= shortestHeight_.GetValue() && h.GetValue() <= tallestHeight_.GetValue();
  } else {
    return h.GetValue() > shortestHeight_.GetValue() && h.GetValue() < tallestHeight_.GetValue();
  }
}

Height HeightRange::Width() const {
  double widthValue = tallestHeight_.GetValue() - shortestHeight_.GetValue();
  return Height(widthValue, tallestHeight_.GetUnits());
}